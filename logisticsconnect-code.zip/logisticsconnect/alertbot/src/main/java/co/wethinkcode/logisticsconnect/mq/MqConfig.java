package co.wethinkcode.logisticsconnect.mq;

/** Shared broker settings. Duplicated into every service that talks to the topic. */
public final class MqConfig {
    public static final String BROKER_URL =
            System.getenv().getOrDefault("MQ_BROKER_URL", "tcp://localhost:61616");
    public static final String TOPIC = "package-status-topic";

    private MqConfig() {}
}
