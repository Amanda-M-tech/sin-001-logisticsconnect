package co.wethinkcode.logisticsconnect;

import co.wethinkcode.logisticsconnect.mq.MqConfig;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.javalin.Javalin;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Subscribes to package-status-topic and "posts" an alert when a hub's stage crosses the threshold. */
public class AlertBotApp {

    static final int PORT = 7054;
    static final int THRESHOLD = Integer.parseInt(System.getenv().getOrDefault("ALERT_THRESHOLD", "5"));
    static final ObjectMapper MAPPER = new ObjectMapper();
    static final Map<String, Integer> LAST_STAGE = new ConcurrentHashMap<>();
    static final List<String> POSTS = new CopyOnWriteArrayList<>();

    public static void main(String[] args) {
        startSubscriber();
        Javalin.create()
                .get("/health", ctx -> ctx.result("OK"))
                .get("/alerts", ctx -> ctx.json(POSTS))   // everything the bot has "posted"
                .start(PORT);
    }

    static void handle(String hubId, int stage) {
        int previous = LAST_STAGE.getOrDefault(hubId, 0);
        LAST_STAGE.put(hubId, stage);
        String post = null;
        if (previous < THRESHOLD && stage >= THRESHOLD) {
            post = "⚠️ Transit alert: hub " + hubId + " is now at delay stage " + stage
                    + ". Expect significant parcel delays. #LogisticsConnect";
        } else if (previous >= THRESHOLD && stage < THRESHOLD) {
            post = "✅ Update: hub " + hubId + " delays have eased to stage " + stage + ".";
        }
        if (post != null) {
            String line = Instant.now() + " " + post;
            POSTS.add(line);
            System.out.println("[SIMULATED SOCIAL POST] " + line);
        }
    }

    static void startSubscriber() {
        Thread t = new Thread(() -> {
            while (true) {
                try {
                    Connection c = new ActiveMQConnectionFactory(MqConfig.BROKER_URL).createConnection();
                    c.setClientID("alertbot");
                    Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
                    Topic topic = s.createTopic(MqConfig.TOPIC);
                    MessageConsumer consumer = s.createDurableSubscriber(topic, "alertbot-sub");
                    consumer.setMessageListener(m -> {
                        try {
                            JsonNode n = MAPPER.readTree(((TextMessage) m).getText());
                            handle(n.get("hubId").asText().toUpperCase(), n.get("stage").asInt());
                        } catch (Exception e) {
                            System.err.println("Bad message ignored: " + e.getMessage());
                        }
                    });
                    c.start();
                    System.out.println("AlertBot subscribed (threshold stage " + THRESHOLD + ")");
                    return;
                } catch (Exception e) {
                    System.out.println("Broker not ready, retrying in 3s: " + e.getMessage());
                    try { Thread.sleep(3000); } catch (InterruptedException ie) { return; }
                }
            }
        }, "mq-subscriber");
        t.setDaemon(true);
        t.start();
    }
}
