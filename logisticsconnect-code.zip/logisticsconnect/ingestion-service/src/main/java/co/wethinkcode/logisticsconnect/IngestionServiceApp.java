package co.wethinkcode.logisticsconnect;

import io.javalin.Javalin;
import io.javalin.http.NotFoundResponse;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Stage 1: parse + clean the messy legacy hubs-global.csv and serve it over REST. */
public class IngestionServiceApp {

    static final int PORT = 7050;

    private static final Set<String> PLACEHOLDERS =
            Set.of("", "n/a", "na", "tbd", "unknown", "-", "nan", "null", "none");

    private static final Map<String, Boolean> BOOLEANS = Map.ofEntries(
            Map.entry("y", true), Map.entry("yes", true), Map.entry("true", true), Map.entry("t", true), Map.entry("1", true),
            Map.entry("n", false), Map.entry("no", false), Map.entry("false", false), Map.entry("f", false), Map.entry("0", false));

    private static final Map<String, Integer> NUMBER_WORDS = Map.ofEntries(
            Map.entry("zero", 0), Map.entry("one", 1), Map.entry("two", 2), Map.entry("three", 3), Map.entry("four", 4),
            Map.entry("five", 5), Map.entry("six", 6), Map.entry("seven", 7), Map.entry("eight", 8), Map.entry("nine", 9),
            Map.entry("ten", 10), Map.entry("twenty", 20), Map.entry("thirty", 30), Map.entry("fifty", 50), Map.entry("hundred", 100));

    /** Naming / spelling variants -> canonical name. Keys are lower-case, punctuation stripped. EXTEND THIS after eyeballing the CSV. */
    private static final Map<String, String> SYNONYMS = Map.ofEntries(
            Map.entry("jhb central", "Johannesburg Central"),
            Map.entry("joburg central", "Johannesburg Central"),
            Map.entry("johannesburg center", "Johannesburg Central"),
            Map.entry("johannesburg centre", "Johannesburg Central"),
            Map.entry("tshwane north", "Pretoria North"),
            Map.entry("pta north", "Pretoria North"),
            Map.entry("kzn", "KwaZulu-Natal"),
            Map.entry("kwazulu natal", "KwaZulu-Natal"),
            Map.entry("w cape", "Western Cape"),
            Map.entry("wc", "Western Cape"),
            Map.entry("e cape", "Eastern Cape"),
            Map.entry("gp", "Gauteng"));

    private static final List<DateTimeFormatter> DATE_FORMATS = List.of(
            fmt("uuuu-M-d"),     // 2026-07-18, 2026-7-8
            fmt("M/d/uuuu"),     // MM/DD/YYYY (slashes are month-first)
            fmt("d-M-uuuu"));    // DD-MM-YYYY (dashes are day-first)

    private static DateTimeFormatter fmt(String p) {
        return DateTimeFormatter.ofPattern(p).withResolverStyle(ResolverStyle.STRICT);
    }

    static final List<Map<String, Object>> CLEANED = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        CLEANED.addAll(loadAndClean("/hubs-global.csv"));
        System.out.println("Cleaned records: " + CLEANED.size());

        Javalin.create()
                .get("/health", ctx -> ctx.result("OK"))
                .get("/hubs", ctx -> ctx.json(CLEANED))
                .get("/hubs/{hubId}", ctx -> {
                    String id = ctx.pathParam("hubId").trim().toUpperCase();
                    CLEANED.stream()
                            .filter(h -> id.equals(h.get("hub_id")) || ((List<?>) h.getOrDefault("aliases", List.of())).contains(id))
                            .findFirst()
                            .ifPresentOrElse(ctx::json, () -> { throw new NotFoundResponse("Unknown hub " + id); });
                })
                .start(PORT);
    }

    // ------------------------------------------------------------------ pipeline

    static List<Map<String, Object>> loadAndClean(String resource) throws Exception {
        String text;
        try (InputStream in = IngestionServiceApp.class.getResourceAsStream(resource)) {
            if (in == null) throw new IllegalStateException(resource + " not found on classpath");
            text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
        List<List<String>> rows = parseCsv(text);
        List<String> header = new ArrayList<>();
        for (String h : rows.get(0)) header.add(h.trim().toLowerCase().replaceAll("[\\s]+", "_"));

        List<Map<String, Object>> records = new ArrayList<>();
        for (List<String> row : rows.subList(1, rows.size())) {
            if (row.stream().allMatch(c -> c.isBlank())) continue;           // blank line
            Map<String, Object> rec = new LinkedHashMap<>();
            for (int i = 0; i < header.size(); i++) {
                String raw = i < row.size() ? row.get(i) : "";
                rec.put(header.get(i), cleanValue(header.get(i), raw));
            }
            if (rec.get("hub_id") == null) continue;                          // unusable without an id
            records.add(rec);
        }
        return deduplicate(records);
    }

    static Object cleanValue(String col, String raw) {
        String v = raw.trim().replaceAll("\\s+", " ");                        // padding + double spaces
        if (PLACEHOLDERS.contains(v.toLowerCase())) return null;             // missing / placeholder

        if (col.equals("hub_id") || col.equals("id") || col.endsWith("_id")) {
            Matcher m = Pattern.compile("^([A-Za-z]+)[-_ ]?(\\d+)$").matcher(v);
            return m.matches() ? m.group(1).toUpperCase() + "-" + m.group(2) : v.toUpperCase();
        }
        if (col.contains("date") || col.contains("since")) return parseDate(v);

        boolean flagColumn = col.matches(".*(active|enabled|flag|operational).*") || col.startsWith("is_") || col.startsWith("has_");
        if (flagColumn || (BOOLEANS.containsKey(v.toLowerCase()) && !v.matches("\\d+"))) {
            return BOOLEANS.get(v.toLowerCase());                             // null if unparseable
        }
        if (col.matches(".*(count|capacity|size|staff|parcel|number|volume|total|qty|quantity).*")) return parseCount(v);

        return canonicalName(v);
    }

    static String canonicalName(String v) {
        StringBuilder sb = new StringBuilder();
        for (String w : v.toLowerCase().split(" ")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        String title = sb.toString();
        String key = title.toLowerCase().replaceAll("\\bcentre\\b", "center").replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        String syn = SYNONYMS.get(key);
        if (syn != null) return syn;
        return title.replaceAll("\\bCentre\\b", "Center");                    // regional spelling variant
    }

    static String parseDate(String v) {
        for (DateTimeFormatter f : DATE_FORMATS) {
            try { return LocalDate.parse(v, f).toString(); } catch (Exception ignored) { }
        }
        return null;                                                          // outright invalid date
    }

    static Integer parseCount(String v) {
        String s = v.toLowerCase().replace(",", "");
        Integer n = NUMBER_WORDS.get(s);
        if (n == null) {
            try { n = (int) Math.round(Double.parseDouble(s)); } catch (NumberFormatException e) { return null; }
        }
        return (n < 0 || n > 1_000_000) ? null : n;                           // negative / unrealistic
    }

    /**
     * Duplicates = same real-world place (province + sorting centre, normalised) under different hub ids.
     * Winner: most populated fields, ties -> lowest hub id. Losers' ids are kept in "aliases"
     * and any null field on the winner is back-filled from them.
     */
    static List<Map<String, Object>> deduplicate(List<Map<String, Object>> records) {
        Map<String, List<Map<String, Object>>> groups = new LinkedHashMap<>();
        for (Map<String, Object> r : records) {
            Object prov = r.get("province"), sc = r.get("sorting_center");
            String key = (prov != null && sc != null)
                    ? (prov + "|" + sc).toLowerCase()
                    : "id:" + r.get("hub_id");
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(r);
        }
        List<Map<String, Object>> out = new ArrayList<>();
        for (List<Map<String, Object>> g : groups.values()) {
            g.sort(Comparator
                    .comparingLong((Map<String, Object> r) -> -r.values().stream().filter(Objects::nonNull).count())
                    .thenComparing(r -> String.valueOf(r.get("hub_id"))));
            Map<String, Object> winner = new LinkedHashMap<>(g.get(0));
            List<String> aliases = new ArrayList<>();
            for (Map<String, Object> other : g.subList(1, g.size())) {
                String otherId = String.valueOf(other.get("hub_id"));
                if (!otherId.equals(winner.get("hub_id")) && !aliases.contains(otherId)) aliases.add(otherId);
                other.forEach((k, val) -> { if (winner.get(k) == null && val != null) winner.put(k, val); });
            }
            if (!aliases.isEmpty()) winner.put("aliases", aliases);
            out.add(winner);
        }
        out.sort(Comparator.comparing(r -> String.valueOf(r.get("hub_id"))));
        return out;
    }

    /** Minimal RFC-4180-ish CSV parser (quotes, escaped quotes, CRLF). */
    static List<List<String>> parseCsv(String text) {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') { cell.append('"'); i++; }
                    else quoted = false;
                } else cell.append(c);
            } else if (c == '"') quoted = true;
            else if (c == ',') { row.add(cell.toString()); cell.setLength(0); }
            else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                row.add(cell.toString()); cell.setLength(0);
                rows.add(row); row = new ArrayList<>();
            } else cell.append(c);
        }
        if (cell.length() > 0 || !row.isEmpty()) { row.add(cell.toString()); rows.add(row); }
        return rows;
    }
}
