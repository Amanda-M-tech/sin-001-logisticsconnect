package co.wethinkcode.logisticsconnect;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.javalin.Javalin;
import io.javalin.http.NotFoundResponse;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/** Place-name source of truth. Loads cleaned hubs from ingestion-service over REST. */
public class HubServiceApp {

    static final int PORT = 7051;
    static final String INGESTION_URL = System.getenv().getOrDefault("INGESTION_URL", "http://localhost:7050");
    static final ObjectMapper MAPPER = new ObjectMapper();
    static final HttpClient HTTP = HttpClient.newHttpClient();
    static final Map<String, Map<String, Object>> HUBS = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        loadHubs();

        Javalin.create()
                .get("/health", ctx -> ctx.result("OK"))
                .get("/hubs", ctx -> ctx.json(new TreeMap<>(HUBS).values()))
                .get("/hubs/{hubId}", ctx -> {
                    Map<String, Object> hub = HUBS.get(ctx.pathParam("hubId").trim().toUpperCase());
                    if (hub == null) throw new NotFoundResponse("Unknown hub " + ctx.pathParam("hubId"));
                    ctx.json(hub);
                })
                .get("/provinces", ctx -> ctx.json(HUBS.values().stream()
                        .map(h -> (String) h.get("province")).filter(Objects::nonNull)
                        .distinct().sorted().collect(Collectors.toList())))
                .get("/sorting-centers", ctx -> {
                    String province = ctx.queryParam("province");
                    ctx.json(HUBS.values().stream()
                            .filter(h -> province == null || province.equalsIgnoreCase((String) h.get("province")))
                            .map(h -> (String) h.get("sorting_center")).filter(Objects::nonNull)
                            .distinct().sorted().collect(Collectors.toList()));
                })
                .post("/reload", ctx -> { loadHubs(); ctx.json(Map.of("loaded", HUBS.size())); })
                .start(PORT);
    }

    /** Synchronous REST call to ingestion-service; retries so start-up order doesn't matter. */
    static void loadHubs() {
        for (int attempt = 1; attempt <= 15; attempt++) {
            try {
                HttpResponse<String> r = HTTP.send(
                        HttpRequest.newBuilder(URI.create(INGESTION_URL + "/hubs")).GET().build(),
                        HttpResponse.BodyHandlers.ofString());
                if (r.statusCode() == 200) {
                    List<Map<String, Object>> list =
                            MAPPER.readValue(r.body(), new TypeReference<List<Map<String, Object>>>() { });
                    HUBS.clear();
                    for (Map<String, Object> h : list) {
                        HUBS.put(String.valueOf(h.get("hub_id")).toUpperCase(), h);
                        Object aliases = h.get("aliases");
                        if (aliases instanceof List<?> l) l.forEach(a -> HUBS.putIfAbsent(String.valueOf(a).toUpperCase(), h));
                    }
                    System.out.println("Loaded " + list.size() + " hubs from ingestion-service");
                    return;
                }
            } catch (Exception e) {
                System.out.println("ingestion-service not ready (attempt " + attempt + "): " + e.getMessage());
            }
            try { Thread.sleep(2000); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); return; }
        }
        System.out.println("WARNING: starting with no hub data; POST /reload once ingestion-service is up");
    }
}
