# Drop-in code for LogisticsConnect (stages 1-4)

Copy each module's `src/main/java/...` files over your scaffold (keep your own pom.xml if it
already builds; just make sure it has: javalin 6.x, jackson-databind, slf4j-simple, and
activemq-client 5.18.x for delay-stage-service / transit-service / alertbot).

Suggested commits (steady history = one commit per step, push as you go):
1. ingestion: CSV parser + cleaning rules
2. ingestion: dedupe + /hubs endpoints
3. hub-service: load from ingestion, /hubs /provinces /sorting-centers
4. delay-stage-service: GET/POST stage (in-memory)
5. transit-service: /eta using hub-service + REST call to delay-stage-service  (stage 2 milestone)
6. common: docker-compose + MqConfig; delay-stage publishes on POST
7. transit-service: replace REST stage call with durable topic subscription (stage 3)
8. alertbot: threshold alerts (stretch)
9. README: document design decisions (dedupe rule, ETA formula)

Smoke test:
  cd common && docker compose up -d
  (start ingestion, hub, delay-stage, transit, alertbot)
  curl localhost:7051/hubs/H-502
  curl localhost:7053/eta/H-502
  curl -X POST localhost:7052/delay-stage/H-502 -H 'Content-Type: application/json' -d '{"stage":6}'
  curl localhost:7053/eta/H-502        # later window, status DELAYED
  curl localhost:7054/alerts           # alert was "posted"
