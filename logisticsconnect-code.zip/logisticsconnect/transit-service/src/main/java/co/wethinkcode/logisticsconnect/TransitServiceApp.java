package co.wethinkcode.logisticsconnect;

import co.wethinkcode.logisticsconnect.mq.MqConfig;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.javalin.Javalin;
import io.javalin.http.NotFoundResponse;
import io.javalin.http.ServiceUnavailableResponse;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.Connection;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * ETA calculator.
 *  - hub details:  synchronous REST call to hub-service  (stage 2)
 *  - delay stage:  async, learned from package-status-topic (stage 3, replaces GET :7052/delay-stage/{hubId})
 */
public class TransitServiceApp {

    static final int PORT = 7053;
    static final String HUB_URL = System.getenv().getOrDefault("HUB_URL", "http://localhost:7051");
    static final ObjectMapper MAPPER = new ObjectMapper();
    static final HttpClient HTTP = HttpClient.newHttpClient();

    /** Local read-model of the latest stage per hub, fed by the topic. */
    static final Map<String, Integer> STAGE_CACHE = new ConcurrentHashMap<>();

    static final int BASE_HOURS = 24;
    static final int HOURS_PER_STAGE = 6;
    static final int SUSPENDED_STAGE = 8;

    public static void main(String[] args) {
        startSubscriber();

        Javalin.create()
                .get("/health", ctx -> ctx.result("OK"))
                .get("/stages", ctx -> ctx.json(STAGE_CACHE))
                .get("/eta/{hubId}", ctx -> {
                    String hubId = ctx.pathParam("hubId").trim().toUpperCase();
                    Map<String, Object> hub = fetchHub(hubId);
                    int stage = STAGE_CACHE.getOrDefault(hubId, 0);

                    Map<String, Object> res = new LinkedHashMap<>();
                    res.put("hubId", hubId);
                    res.put("province", hub.get("province"));
                    res.put("sortingCenter", hub.get("sorting_center"));
                    res.put("hubActive", hub.get("active"));
                    res.put("delayStage", stage);

                    if (stage >= SUSPENDED_STAGE) {
                        res.put("status", "SUSPENDED");
                        res.put("estimatedArrivalFrom", null);
                        res.put("estimatedArrivalTo", null);
                    } else {
                        Instant from = Instant.now().plus(BASE_HOURS + (long) stage * HOURS_PER_STAGE, ChronoUnit.HOURS);
                        Instant to = from.plus(4 + (long) stage * 2, ChronoUnit.HOURS);  // window widens with delay
                        res.put("status", stage == 0 ? "ON_TIME" : "DELAYED");
                        res.put("estimatedArrivalFrom", from.toString());
                        res.put("estimatedArrivalTo", to.toString());
                    }
                    ctx.json(res);
                })
                .start(PORT);
    }

    static Map<String, Object> fetchHub(String hubId) throws Exception {
        HttpResponse<String> r;
        try {
            r = HTTP.send(HttpRequest.newBuilder(URI.create(
                    HUB_URL + "/hubs/" + URLEncoder.encode(hubId, StandardCharsets.UTF_8))).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
        } catch (java.io.IOException e) {
            throw new ServiceUnavailableResponse("hub-service unreachable");
        }
        if (r.statusCode() == 404) throw new NotFoundResponse("Unknown hub " + hubId);
        if (r.statusCode() != 200) throw new ServiceUnavailableResponse("hub-service returned " + r.statusCode());
        return MAPPER.readValue(r.body(), new TypeReference<Map<String, Object>>() { });
    }

    /** Durable topic subscription, retried in the background so the broker may start later. */
    static void startSubscriber() {
        Thread t = new Thread(() -> {
            while (true) {
                try {
                    Connection c = new ActiveMQConnectionFactory(MqConfig.BROKER_URL).createConnection();
                    c.setClientID("transit-service");           // required for a durable subscription
                    Session s = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
                    Topic topic = s.createTopic(MqConfig.TOPIC);
                    MessageConsumer consumer = s.createDurableSubscriber(topic, "transit-service-sub");
                    consumer.setMessageListener(m -> {
                        try {
                            JsonNode n = MAPPER.readTree(((TextMessage) m).getText());
                            STAGE_CACHE.put(n.get("hubId").asText().toUpperCase(), n.get("stage").asInt());
                            System.out.println("Stage update received: " + n);
                        } catch (Exception e) {
                            System.err.println("Bad message ignored: " + e.getMessage());
                        }
                    });
                    c.start();
                    System.out.println("Subscribed to " + MqConfig.TOPIC);
                    return;
                } catch (Exception e) {
                    System.out.println("Broker not ready, retrying in 3s: " + e.getMessage());
                    try { Thread.sleep(3000); } catch (InterruptedException ie) { return; }
                }
            }
        }, "mq-subscriber");
        t.setDaemon(true);
        t.start();
    }
}
