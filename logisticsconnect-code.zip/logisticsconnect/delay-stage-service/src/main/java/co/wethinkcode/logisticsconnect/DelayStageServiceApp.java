package co.wethinkcode.logisticsconnect;

import co.wethinkcode.logisticsconnect.mq.MqConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.javalin.Javalin;
import io.javalin.http.BadRequestResponse;
import io.javalin.http.ServiceUnavailableResponse;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.Connection;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.Topic;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Tracks the Transit Delay Stage (0-8) per hub and publishes every change to package-status-topic. */
public class DelayStageServiceApp {

    static final int PORT = 7052;
    static final ObjectMapper MAPPER = new ObjectMapper();
    static final Map<String, Integer> STAGES = new ConcurrentHashMap<>();

    public record StageRequest(int stage) { }

    private static Connection connection;
    private static Session session;
    private static MessageProducer producer;

    public static void main(String[] args) {
        Javalin.create()
                .get("/health", ctx -> ctx.result("OK"))
                .get("/delay-stage", ctx -> ctx.json(STAGES))
                .get("/delay-stage/{hubId}", ctx -> {
                    String hubId = ctx.pathParam("hubId").trim().toUpperCase();
                    ctx.json(Map.of("hubId", hubId, "stage", STAGES.getOrDefault(hubId, 0)));
                })
                .post("/delay-stage/{hubId}", ctx -> {
                    String hubId = ctx.pathParam("hubId").trim().toUpperCase();
                    int stage;
                    try { stage = ctx.bodyAsClass(StageRequest.class).stage(); }
                    catch (Exception e) { throw new BadRequestResponse("Body must be {\"stage\": 0-8}"); }
                    if (stage < 0 || stage > 8) throw new BadRequestResponse("stage must be between 0 and 8");

                    Map<String, Object> msg = new LinkedHashMap<>();
                    msg.put("hubId", hubId);
                    msg.put("stage", stage);
                    msg.put("timestamp", Instant.now().toString());

                    publish(MAPPER.writeValueAsString(msg));   // fail first so state and bus never disagree
                    STAGES.put(hubId, stage);
                    ctx.status(202).json(msg);
                })
                .start(PORT);
    }

    private static synchronized void publish(String json) {
        try {
            if (producer == null) {
                connection = new ActiveMQConnectionFactory(MqConfig.BROKER_URL).createConnection();
                connection.start();
                session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                Topic topic = session.createTopic(MqConfig.TOPIC);
                producer = session.createProducer(topic);
            }
            producer.send(session.createTextMessage(json));
            System.out.println("Published to " + MqConfig.TOPIC + ": " + json);
        } catch (Exception e) {
            try { if (connection != null) connection.close(); } catch (Exception ignored) { }
            connection = null; session = null; producer = null;
            throw new ServiceUnavailableResponse("Message broker unavailable: " + e.getMessage());
        }
    }
}
